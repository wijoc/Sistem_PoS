$(document).ready(function(){
    /* Datatable */
    $("#table-default").DataTable({
        "responsive": true,
        "autoWidth": false,
    });
})